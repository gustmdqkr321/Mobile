package com.example.first;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

public class pay extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pay);
        setTitle("basket");
        CheckBox pay1 = (CheckBox) findViewById(R.id.pay1);
        CheckBox pay2 = (CheckBox) findViewById(R.id.pay2);
        CheckBox pay3 = (CheckBox) findViewById(R.id.pay3);
        TextView totalpay = (TextView) findViewById(R.id.totalpay);
        Intent inIntent = getIntent();
        final int check1 = inIntent.getIntExtra("CHECK1",0);
        final int check2 = inIntent.getIntExtra("CHECK2",0);
        final int check3 = inIntent.getIntExtra("CHECK3",0);
        int totalpayint = 0;

        if(check1 == 0){
            pay1.setVisibility(View.GONE);
        }
        else{
            totalpayint += 20000;
        }
        if(check2 == 0){
            pay2.setVisibility(View.GONE);
        }
        else{
            totalpayint += 5000;
        }
        if(check3 == 0){
            pay3.setVisibility(View.GONE);
        }
        else{
            totalpayint += 10000;
        }
        totalpay.setText("총 계산 금액 : "+totalpayint);
        Button pay = (Button) findViewById(R.id.pay);
        pay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
