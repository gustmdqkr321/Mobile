package com.example.first;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("main");

        Button btnbasket = (Button) findViewById(R.id.btnbasket);
        btnbasket.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CheckBox checkbox1 = (CheckBox) findViewById(R.id.checkBox);
                CheckBox checkbox2 = (CheckBox) findViewById(R.id.checkBox2);
                CheckBox checkbox3 = (CheckBox) findViewById(R.id.checkBox3);
                Intent intent = new Intent(getApplicationContext(), basket.class);
                if (checkbox1.isChecked()) {
                    intent.putExtra("CHECK1", Integer.parseInt("1"));
                }

                if (checkbox2.isChecked()) {
                    intent.putExtra("CHECK2", Integer.parseInt("1"));
                }

                if (checkbox3.isChecked()) {
                    intent.putExtra("CHECK3", Integer.parseInt("1"));
                }
                startActivityForResult(intent, 0);
            }
        });
        Button btnpay = (Button) findViewById(R.id.btnpay);
        btnpay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CheckBox checkbox1 = (CheckBox) findViewById(R.id.checkBox);
                CheckBox checkbox2 = (CheckBox) findViewById(R.id.checkBox2);
                CheckBox checkbox3 = (CheckBox) findViewById(R.id.checkBox3);
                Intent intent = new Intent(getApplicationContext(), pay.class);
                if (checkbox1.isChecked()) {
                    intent.putExtra("CHECK1", Integer.parseInt("1"));
                }

                if (checkbox2.isChecked()) {
                    intent.putExtra("CHECK2", Integer.parseInt("1"));
                }

                if (checkbox3.isChecked()) {
                    intent.putExtra("CHECK3", Integer.parseInt("1"));
                }
                startActivityForResult(intent, 0);
            }
        });
    }
}