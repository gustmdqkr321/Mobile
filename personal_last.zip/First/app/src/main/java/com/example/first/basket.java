package com.example.first;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class basket extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.basket);
        setTitle("basket");
        CheckBox check4 = (CheckBox) findViewById(R.id.checkBox4);
        CheckBox check5 = (CheckBox) findViewById(R.id.checkBox5);
        CheckBox check6 = (CheckBox) findViewById(R.id.checkBox6);
        Intent inIntent = getIntent();
        final int check1 = inIntent.getIntExtra("CHECK1",0);
        final int check2 = inIntent.getIntExtra("CHECK2",0);
        final int check3 = inIntent.getIntExtra("CHECK3",0);
        if(check1 == 0){
            check4.setVisibility(View.GONE);
        }
        if(check2 == 0){
            check5.setVisibility(View.GONE);
        }
        if(check3 == 0){
            check6.setVisibility(View.GONE);
        }
        Button btnhome = (Button) findViewById(R.id.home);
        btnhome.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        Button btnpay = (Button) findViewById(R.id.pay);
        btnpay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CheckBox checkbox4 = (CheckBox) findViewById(R.id.checkBox4);
                CheckBox checkbox5 = (CheckBox) findViewById(R.id.checkBox5);
                CheckBox checkbox6 = (CheckBox) findViewById(R.id.checkBox6);
                Intent intent = new Intent(getApplicationContext(), pay.class);
                if (checkbox4.isChecked()) {
                    intent.putExtra("CHECK1", Integer.parseInt("1"));
                }

                if (checkbox5.isChecked()) {
                    intent.putExtra("CHECK2", Integer.parseInt("1"));
                }

                if (checkbox6.isChecked()) {
                    intent.putExtra("CHECK3", Integer.parseInt("1"));
                }
                startActivityForResult(intent, 0);
            }
        });
    }
}
